package com.example.example

import com.google.gson.annotations.SerializedName


data class OverviewPolyline (

  @SerializedName("points" ) var points : String? = null

)