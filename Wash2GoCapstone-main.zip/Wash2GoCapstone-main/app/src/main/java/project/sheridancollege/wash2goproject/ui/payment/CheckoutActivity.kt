package project.sheridancollege.wash2goproject.ui.payment


import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import com.stripe.android.ApiResultCallback
import com.stripe.android.PaymentIntentResult
import com.stripe.android.Stripe
import com.stripe.android.model.ConfirmPaymentIntentParams
import com.stripe.android.model.StripeIntent
import com.stripe.android.view.CardInputWidget
import okhttp3.*

import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import project.sheridancollege.wash2goproject.R
import java.io.IOException
import java.lang.ref.WeakReference
import java.util.*

@Suppress("DEPRECATION")
class CheckoutActivityJava : AppCompatActivity() {
    private val httpClient = OkHttpClient()
    private var paymentIntentClientSecret: String? = null
    private var stripe: Stripe? = null
    private var amountTextView: TextView? = null
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)
        amountTextView = findViewById(R.id.amountTextView)

        // Configure the SDK with your Stripe publishable key so it can make requests to Stripe
        stripe = Stripe(
            applicationContext,
            Objects.requireNonNull("pk_test_51LpziCEMdDvjcPOiegKp9RrW5adAYf7AxfS538DFJVq9hm91egKeqfg4JTlHxMDUkIwpglqchLMTehmchg9hzlet00d9ypBkib")
        )
        startCheckout()
    }

    private fun startCheckout() {
        // Create a PaymentIntent by calling the server's endpoint.
        val amount = java.lang.Double.valueOf(amountTextView!!.text.toString()) * 100
        val payMap: MutableMap<String, Any> = HashMap()
        val itemMap: MutableMap<String, Any> = HashMap()
        val itemList: MutableList<Map<String, Any>> = ArrayList()
        payMap["currency"] = "usd" //dont change currency in testing phase otherwise it won't work
        itemMap["id"] = "photo_subscription"
        itemMap["amount"] = amount
        itemList.add(itemMap)
        payMap["items"] = itemList
        val json = Gson().toJson(payMap)
        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(BACKEND_URL + "create-payment-intent")
            .post(body)
            .build()

        httpClient.newCall(request)
            .enqueue(PayCallback(this))
        // Hook up the pay button to the card widget and stripe instance
        val payButton = findViewById<Button>(R.id.payButton)
        payButton.setOnClickListener { view: View? ->
            val cardInputWidget =
                findViewById<CardInputWidget>(R.id.cardInputWidget)
            val params = cardInputWidget.paymentMethodCreateParams
            if (params != null) {
                val confirmParams =
                    ConfirmPaymentIntentParams.createWithPaymentMethodCreateParams(
                        params,
                        paymentIntentClientSecret!!
                    )
                stripe!!.confirmPayment(this, confirmParams)
            }
        }
    }

    private fun displayAlert(
        title: String,
        message: String?
    ) {
        val builder = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
        builder.setPositiveButton("Ok", null)
        builder.create().show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        stripe!!.onPaymentResult(requestCode, data, PaymentResultCallback(this))
    }

    @Throws(IOException::class)
    private fun onPaymentSuccess(response: Response) {
        val gson = Gson()
        val type = object : TypeToken<Map<String?, String?>?>() {}.type
        val responseMap = gson.fromJson<Map<String, String>>(
            Objects.requireNonNull(response.body).toString(),
            type
        )
        paymentIntentClientSecret = responseMap["clientSecret"]
    }

    private class PayCallback  constructor(activity: CheckoutActivityJava) : Callback {
        private val activityRef: WeakReference<CheckoutActivityJava>

        init {
            activityRef = WeakReference(activity)
        }

        override fun onFailure(call: Call, e: IOException) {
            val activity = activityRef.get() ?: return
            activity.runOnUiThread {
                Toast.makeText(
                    activity, "Error: $e", Toast.LENGTH_LONG
                ).show()
            }
        }

        @Throws(IOException::class)
        override fun onResponse(call: Call, response: Response) {
            val activity = activityRef.get() ?: return
            if (!response.isSuccessful) {
                activity.runOnUiThread {
                    Toast.makeText(
                        activity, "Error: $response", Toast.LENGTH_LONG
                    ).show()
                }
            } else {
                activity.onPaymentSuccess(response)
            }
        }
    }

    private class PaymentResultCallback(activity: CheckoutActivityJava) :
        ApiResultCallback<PaymentIntentResult> {
        private val activityRef: WeakReference<CheckoutActivityJava>

        init {
            activityRef = WeakReference(activity)
        }

        override fun onSuccess(result: PaymentIntentResult) {
            val activity = activityRef.get() ?: return
            val paymentIntent = result.intent
            val status: StripeIntent.Status? = paymentIntent.status
            if (status == StripeIntent.Status.Succeeded) {
                // Payment completed successfully
                val gson = GsonBuilder().setPrettyPrinting().create()
                activity.displayAlert(
                    "Payment completed",
                    gson.toJson(paymentIntent)
                )
            } else if (status == StripeIntent.Status.RequiresPaymentMethod) {
                // Payment failed – allow retrying using a different payment method
                activity.displayAlert(
                    "Payment failed",
                    "Payment failed"

                )
            }
        }

        override fun onError(e: Exception) {
            val activity = activityRef.get() ?: return
            // Payment request failed – allow retrying using the same payment method
            activity.displayAlert("Error", e.toString())
        }
    }

    companion object {
        // 10.0.2.2 is the Android emulator's alias to localhost
        private const val BACKEND_URL = "https://shielded-temple-70699.herokuapp.com/"
    }
}