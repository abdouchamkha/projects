package project.sheridancollege.wash2goproject.common

enum class UserStatus {
    ONLINE,
    OFFLINE
}