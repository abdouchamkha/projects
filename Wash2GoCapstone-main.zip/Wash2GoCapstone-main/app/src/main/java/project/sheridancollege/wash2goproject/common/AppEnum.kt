package project.sheridancollege.wash2goproject.common

enum class AppEnum {
    DETAILER,
    CUSTOMER,

    NEW,
    ACTIVE,
    STARTED,
    ARRIVED,
    COMPLETED,
    DECLINED,

    CUSTOMER_REQUEST,
    DETAILER_REQUEST


}