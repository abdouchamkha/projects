package project.sheridancollege.wash2goproject.ui.payment

import android.app.Application
import com.stripe.android.PaymentConfiguration

class MyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PaymentConfiguration.init(
            applicationContext,
            "pk_test_51LpziCEMdDvjcPOiegKp9RrW5adAYf7AxfS538DFJVq9hm91egKeqfg4JTlHxMDUkIwpglqchLMTehmchg9hzlet00d9ypBkib"
        )
    }
}